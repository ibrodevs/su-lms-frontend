window.scormReady = true;
